const obj = {
   0: '10',
   1: '20',
}

for (let val of obj) {
   console.log(val)
}
