let sum = 0

for (let i = 1; i <= 100; i++) {
   sum += i * 10
   console.log('덧셈중..')
}

console.log('합계', sum)
