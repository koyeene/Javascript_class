let str

console.log(str.length)
