const obj = {
   0: '10',
   1: '20',
}

obj.forEach((element) => {
   console.log(element)
})
